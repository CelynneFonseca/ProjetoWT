﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WhereTo.Dominio.Entidades
{
    public class Codigo
    {
        public int CodigoID { get; set; }
        public string CodigoQR { get; set; }
    }
}
