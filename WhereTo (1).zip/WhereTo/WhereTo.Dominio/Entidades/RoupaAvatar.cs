﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WhereTo.Dominio.Entidades
{
    public class RoupaAvatar
    {
        public int RoupaID { get; set; }
        public Random Cor { get; set; }
        public int Local { get; set; }
    }
}
